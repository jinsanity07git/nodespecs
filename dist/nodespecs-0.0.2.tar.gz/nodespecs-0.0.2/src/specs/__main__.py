import sys

from .hardware import info_cpu

def main():
    info_cpu()

if __name__ == "__main__":
    main()