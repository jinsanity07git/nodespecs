from .hardware import *

# Version of the node-specs package
__version__ = "0.0.1"


